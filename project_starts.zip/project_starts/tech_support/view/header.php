<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>SportsProTechincalSupport</title>
    <link rel="stylesheet" type="text/css"
          href="/project_starts/tech_support/main.css">
</head>
<!-- need to chagne proj1 to tech_support and put that in project_starts -->
<!-- the body section -->
<body>
<header><h1>SportsPro Techincal Support</h1><p>Sports management software for the sports enthusiast.</p></h1>
    <a href="/project_starts/tech_support/index.php">Home</a>
</header>
