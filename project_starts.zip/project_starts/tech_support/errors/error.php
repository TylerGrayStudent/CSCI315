
<main>
    <h1>Error</h1>
    <p><?php echo $error; ?></p>
</main>

