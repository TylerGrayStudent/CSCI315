<main>
<h1>Register Product</h1>
  <p>Product (<?php echo $product['productCode']?>) was registered succesfully.</p>

</main>
