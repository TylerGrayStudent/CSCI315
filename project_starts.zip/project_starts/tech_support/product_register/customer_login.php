<main>
  <h1>Customer Login</h1>

  <p>You must login before you can register a product</p>
  <form action="." method="post">
          <input type="hidden" name="action"
                 value="register_product">
          <label>Email:</label> <input type="text" name="email">
          <input type="submit" value="Login">
      </form>


</main>
